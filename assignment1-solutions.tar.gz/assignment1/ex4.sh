#!/bin/bash

# Filename: ex4.sh
#
# Problem: Make a script to prompt the user for an answer.

echo Do you wish to open the pod bay doors?
read inputVar
echo User said \"$inputVar\".

